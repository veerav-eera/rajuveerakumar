import { React } from 'react'
import Postform from '../Components/HTTP request/postform'
import Floatingbutton from '../Components/Floatingicon';

const Home = () => {
    return (
        <>
        <Floatingbutton/>
        </>
    )
}

export default Home
