import styled from 'styled-components';
export const SectionTitle = styled.h1``
export const Languagediv = styled.div``
export const LanguageIcon = styled.div``
export const Projectlist = styled.ul``
export const ProjectName = styled.li``