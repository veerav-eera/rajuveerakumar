import styled, { keyframes } from 'styled-components'

export const Section = styled.div`
display:flex;
height:600px;
width:100%;
background: black;
z-index:20;
`
export const SectionContainer = styled.div`
`
